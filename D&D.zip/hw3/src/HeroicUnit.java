
import java.util.ArrayList;

public interface HeroicUnit {

    void castAbility(ArrayList<Enemy> enemies);
    void castAbility(Player player);

}
