public class cmdPrinter {
    public static void sendMessage(String message) {
        System.out.println(message);
    }
}
